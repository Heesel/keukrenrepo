
<?php $__env->startSection('content'); ?>
<link href="<?php echo e(asset('css/profile.css')); ?>" rel="stylesheet">
<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.2.0/css/all.css" integrity="sha384-hWVjflwFxL6sNzntih27bfxkr27PmbbK/iSvJ+a4+0owXq79v+lsFkW54bOGbiDQ" crossorigin="anonymous">
<link href="https://fonts.googleapis.com/css?family=Montserrat|Roboto:300,400|Yellowtail" rel="stylesheet">
<link href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
<div class="container">
<style>
   .profile-pic {
    display: false;
    position: absolute;
    margin: false;
    top: -90px;
    left: 50%;
    right: false;
    bottom: false;
    -webkit-transform: translateX(-50%);
            transform: translateX(-50%);
    height: 180px;
    width: 180px;
    border: 10px solid #fff;
    border-radius: 100%;
    background: url("/storage/uploads/avatars/<?php echo e($user->avatar); ?>") center no-repeat;
    background-size: cover;
  }
</style>

<!-- PAGE STUFF -->
<div class="rela-block profile-card">
   <div class="profile-pic" id="profile_pic"></div>
      <div class="rela-block profile-name-container">
         <div class="rela-block user-name" id="user_name"><?php echo e($user->name); ?></div>
            <div class="rela-block user-desc" id="user_description">
            <?php if(Auth::user()->id == $user->id): ?>
               <?php echo e($user->email); ?>

            <?php endif; ?>
            
            </div>
            <div class="editbutton">
               <?php if(!Auth::guest()): ?>
                  <?php if(Auth::user()->id == $user->id): ?>
                     <a href="/profile/<?php echo e($user->id); ?>/edit" class="btn btn-success">Bewerken <i class="fas fa-user-edit"></i></a>
                  <?php endif; ?>
               <?php endif; ?>
            </div>
         </div>
      </div>
   </div>

   <h3 class="pb-3 mb-4 font-italic border-bottom">
      <?php if(Auth::user()->id == $user->id): ?>
            Jouw favoriete keukens
            <?php else: ?> De favoriete keukens van <strong><?php echo e($user->name); ?></strong>
         <?php endif; ?>
   </h3>
   <div class="row">
   <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
   <div class="col-md-6">
      <div class="card border-success flex-md-row mb-4 shadow-sm h-md-250">
         <div class="card-body d-flex flex-column align-items-start">
            <strong class="d-inline-block mb-2 text-success"><?php echo e($post->title); ?></strong>
            <h6 class="mb-0">
               <a class="text-dark" href="../posts/<?php echo e($post->id); ?>">Geschreven door <strong><?php echo e($post->user->name); ?></strong></a>
            </h6>
            <div class="mb-1 text-muted small"><?php echo e($post->created_at); ?></div>
               <p class="card-text mb-auto"><?php echo \Illuminate\Support\Str::limit($post->body ?? '',70,'...'); ?></p>
               <a class="btn btn-outline-success btn-sm" href="#">Lees meer</a>
         </div>
         <img class="card-img-right flex-auto d-none d-lg-block" alt="" src="/storage/cover_images/<?php echo e($post->cover_image); ?>" style="width: 200px; height: 250px;">
      </div>
   </div>
   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
   </div>

   <h3 class="mt-3 pb-3 mb-4 border-bottom">
        Keuken Nieuws
     </h3>
     <div class="row">
      <?php if(count($posts) > 0): ?>
      <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <div class="col-md-6">
         <div class="card flex-md-row mb-4 h-md-250">
            <div class="card-body d-flex flex-column align-items-start">
               <strong class="d-inline-block mb-2">Keuken nieuwtjes</strong>
               <h6 class="mb-0">
                  <a class="text-dark" href="/posts/<?php echo e($post->id); ?>"><?php echo e($post->title); ?></a>
               </h6>
               <a href="/profile/<?php echo e($post->user_id); ?>" style="text-decoration: none; color: black;"><div class="mb-1 text-muted small">geschreven door <?php echo e($post->user->name); ?></a>
            </div>
            <p class="card-text mb-auto"> <?php echo \Illuminate\Support\Str::limit($post->body ?? '',50,'...'); ?></p>
            <a class="btn btn-success btn-sm" href="/posts/<?php echo e($post->id); ?>">Lees meer</a>
            <?php if(auth()->guard()->check()): ?>
               <a href="javascript:void(0);" onclick="document.getElementById('favorite-form-<?php echo e($post->id); ?>').submit();">
                  <i class="fas fa-heart"></i>
               </a>
               <form id="favorite-form-<?php echo e($post->id); ?>" method="POST" action="<?php echo e(route('post.favorite', $post->id)); ?>" style="display: none;">
                  <?php echo csrf_field(); ?>
               </form>
            <?php endif; ?>
         </div>
         <img class="card-img-right" alt="" src="/storage/cover_images/<?php echo e($post->cover_image); ?>">
      </div>
      </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      <?php else: ?>
         <p>no posts found</p>
      <?php endif; ?>
      <a class="btn btn-success btn-sm all" href="/keukens">Bekijk al het niews</a>
     </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Deltionn\sprint7\keukrenrepo\resources\views/pages/profile.blade.php ENDPATH**/ ?>