
<nav class="navbar navbar-expand-md navbar-light bg-light shadow-sm">
    <a class="navbar-brand" href="<?php echo e(url('/')); ?>">
        <img src="https://keukenfabrikant.nl/wp-content/uploads/2018/05/keukenfabrikant-1200280-300x70.png"
        alt="logo" height="60px" alt="LogoInfocus">
    </a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="<?php echo e(__('Toggle navigation')); ?>">
        <span class="navbar-toggler-icon"></span>
    </button>

    <div class="collapse navbar-collapse" id="navbarSupportedContent">
        <!-- Left Side Of Navbar -->
        <ul class="navbar-nav ml-auto">

        <!-- Right Side Of Navbar -->
        <ul class="navbar-nav mr-auto">
            <!-- Authentication Links -->
            <?php if(auth()->guard()->guest()): ?>
                <li class="nav-item">
                    <a class="nav-link" href="<?php echo e(route('login')); ?>"><?php echo e(__('Login')); ?></a>
                </li>
                <?php if(Route::has('register')): ?>
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(route('register')); ?>"><?php echo e(__('Register')); ?></a>
                    </li>
                <?php endif; ?>
                &nbsp; 
                <li class="nav-item">
                <a href="/contact" class="nav-link">contact</a>
                </li>
            <?php else: ?>
            <?php if(Auth::user()->blocked == '1'): ?>
                <style>
                    .dropdown {
                        right: 0;
                        left: auto;
                    }
                </style>
                <div class="user-profile">
                    <div class="dropdown">      
                        <button class="btn btn-secondary dropdown-toggle" type="button" id="dropdownMenu2" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" style="position:relative; padding-left:50px;">
                            <img src="/storage/uploads/avatars/<?php echo e(Auth::user()->avatar); ?>" style="width:32px; height:32px; position:absolute; top:1px; left:10px; border-radius:50%;">
                            <?php echo e(Auth::user()->name); ?>

                        </button>
                        <div class="dropdown-menu" aria-labelledby="dropdownMenu2">  
                                <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST">
                                    <button class="dropdown-item" href="<?php echo e(route('logout')); ?>">Logout</button>
                                    <?php echo csrf_field(); ?>
                                </form>
                        </div>
                    </div>
                </div>
            <?php elseif(Auth::user()->blocked == '0'): ?>
                <style>
                    .dropdown {
                        right: 0;
                        left: auto;
                    }
                </style>
                <li class="nav-item">
                    <a href="/faq" class="nav-link">Veelgestelde vragen</a>
                </li>
                <li class="nav-item">
                    <a href="/contact" class="nav-link">contact</a>
                </li>
                <div class="user-profile">
                    <div class="dropdown">      
                        <button class="btn btn-secondary dropdown-toggle" type="button" id="dropdownMenu2" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" style="position:relative; padding-left:50px;">
                            <img src="/storage/uploads/avatars/<?php echo e(Auth::user()->avatar); ?>" style="width:32px; height:32px; position:absolute; top:1px; left:10px; border-radius:50%;">
                            <?php echo e(Auth::user()->name); ?>

                            </button>
                            <div class="dropdown-menu" aria-labelledby="dropdownMenu2">  
                            <a class="dropdown-item" type="button" href="/profile/<?php echo e(Auth::user()->id); ?>"><i class="fas fa-address-card"></i>Profielpagina</a>                  
                            <a class="dropdown-item" type="button" href="/posts/create"><i class="fas fa-pencil-alt"></i>Maak Post</a>
                            <a class="dropdown-item" type="button" href="/overzicht"><i class="fas fa-pencil-alt"></i>post overzicht</a>
                            <?php if(Auth::user()->role == 'admin'): ?>
                                <a class="dropdown-item" type="button" href="/admin/users"><i class="fas fa-user-shield"></i>Admin paneel</a>
                            <?php endif; ?>
                                <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST">
                                    <button class="dropdown-item" href="<?php echo e(route('logout')); ?>"><i class="fas fa-sign-out-alt"></i>Logout</button>
                                    <?php echo csrf_field(); ?>
                                </form>
                        </div>
                        &nbsp; 
                    </div>
                </div>
                
            <?php endif; ?>
        <?php endif; ?>  
    </ul>
</div>
</div>
</nav>
<?php /**PATH C:\Deltionn\sprint7\keukrenrepo\resources\views/partials/navbar.blade.php ENDPATH**/ ?>