
<?php $__env->startSection('content'); ?>
<div class="container">
    <a href="/" class="btn btn-dark">Go Back</a><br><br>
    <h1><?php echo e($post->title); ?></h1>
    <a href="/profile/<?php echo e($post->user_id); ?>" style="text-decoration: none; color: black;"><small>geschreven door <?php echo e($post->user->name); ?> op <?php echo e($post->created_at); ?></small></a>
    <div>
        <img class="postimage" src="storage/app/public/cover_images/<?php echo e($post->cover_image); ?>">
        <hr>
        <h4>
        <?php echo nl2br(e($post->body)); ?>

        </h4>
    </div>
    <hr>
    <div class="row">
        <?php if(!Auth::guest()): ?>
            <?php if(Auth::user()->id == $post->user_id): ?>
                <a href="/posts/<?php echo e($post->id); ?>/edit" class="btn btn-trash">Bewerken</a>
                <br>
                <br>
                <?php echo Form::open(['action' => ['PostsController@destroy', $post->id], 'method' => 'POST', 'class' => 'col-xs-offset-2']); ?>

                    <?php echo e(Form::hidden('_method', 'DELETE')); ?>

                    <?php echo e(Form::submit('Verwijder', ['class' => 'btn btn-danger'])); ?>

                <?php echo Form::close(); ?>

                <br>
                <br>
            <?php elseif(Auth::user()->role == 'admin'): ?>
                <a href="/posts/<?php echo e($post->id); ?>/edit" class="btn btn-trash">edit</a>
                <br>
                <br>
                <?php echo Form::open(['action' => ['PostsController@destroy', $post->id], 'method' => 'POST', 'class' => 'col-xs-offset-2']); ?>

                    <?php echo e(Form::hidden('_method', 'DELETE')); ?>

                    <?php echo e(Form::submit('Delete', ['class' => 'btn btn-danger'])); ?>

                <?php echo Form::close(); ?>

                <br>
                <br>
            <?php endif; ?>
        </div>
        

        <div class="row">
            <div class="col-md-8">
            <!-- vraag 1 knop -->
                <p>
                    <button class="btn btn-success btn-lg" id="commentplaatsbtn" type="button" data-toggle="collapse" data-target="#collapse" aria-expanded="false" aria-controls="collapse">Plaats reactie</button>
                </p>
            <!-- antwoord dat uitklapt -->
            <div class="collapse" id="collapse">
                <div id="comment-form" style="margin-top: 30px;">
                    <?php echo Form::open(['route' => ['comments.stored', $post->id], 'method' => 'POST']); ?>

                        <div class="row">
                            <div class="col-md-12">
                                <div class="commentname"> Reactie: </div>
                                <?php echo e(Form::textarea('comment', null, ['class' => 'form-control', 'id' => 'commenttextarea', 'rows' => '4', 'placeholder' => 'Typ hier uw reactie...'])); ?> 
                                <?php echo e(Form::submit('Reactie plaatsen', ['type' => 'button', 'class' => 'btn btn-success'])); ?>

                            </div>
                        </div>
                        <?php echo Form::close(); ?>

                    </div>
                </div>
            </div>
        </div>

        
    <?php endif; ?>
    <div class="row">
        <div class="col-md-8" style="margin-top: 30px;">
            <div class="comment-container">
                <?php $__currentLoopData = $post->comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="commentname"><?php echo e($comment->name); ?> :</div>
                    <div class="comment">
                        <br/>
                        <div class="comment-text"><?php echo nl2br(e($comment->comment)); ?></div>
                        <?php echo Form::open(['action' => ['CommentsController@destroy', $comment->id], 'method' => 'POST', 'class' => 'col-xs-offset-2']); ?>

                            <?php echo e(Form::hidden('_method', 'DELETE')); ?>

                            <?php echo e(Form::submit('Verwijder', ['class' => 'btn btn-trash'])); ?>

                        <?php echo Form::close(); ?>

                        <br>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Deltionn\sprint7\keukrenrepo\resources\views/posts/show.blade.php ENDPATH**/ ?>