
<?php $__env->startSection('content'); ?>
    <div class="container">
    <button class="btn btn-success btn-lg"><a href="/admin/FAQ/create"> Nieuwe vraag aanmaken</a></button>
        <div class="d-flex justify-content-center">
        <table class="table table-bordered">
            <thead class="thead-dark">
            <tr>
                <th scope="col">Id</th>
                <th scope="col">Vraag</th>
                <th scope="col">Antwoord</th>
                <th scope="col">Bewerken</th>
                <th scope="col">Verwijderen</th>
            </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $questions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <th scope="row"><?php echo e($question->id); ?></th>
                <td><?php echo \Illuminate\Support\Str::limit($question->question ?? '',40,'...'); ?></td> 
                <td><?php echo \Illuminate\Support\Str::limit($question->answer ?? '',70,'...'); ?></td>
                <td><button class="btn btn-success"><a href="/admin/FAQ/<?php echo e($question->id); ?>/edit">bewerken</a></button></td>
                <td>
                    <?php echo Form::open(['action' => ['FAQAdminController@destroy', $question->id], 'method' => 'POST', 'class' => 'pull-right']); ?>

                        <?php echo e(Form::hidden('_method', 'DELETE')); ?>

                        <?php echo e(Form::submit('Delete', ['class' => 'btn btn-danger'])); ?>

                    <?php echo Form::close(); ?>

                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
    </div>
</div>
<script type="text/javascript">
    $('.confirmation').click(function(e){
        let result = confirm("Weet je zeker dat je de foto wilt verwijderen?");
        if(!result) {
            e.preventDefault();
        }
    });
</script>
<?php $__env->stopSection(); ?> 
<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Deltionn\sprint7\keukrenrepo\resources\views/panel/FAQ.blade.php ENDPATH**/ ?>