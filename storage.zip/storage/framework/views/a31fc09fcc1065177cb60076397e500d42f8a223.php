<!doctype html>
<html lang="en">
<head class="head">
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link href="<?php echo e(asset('css/bootstrap.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/fontawesome-all.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/bootadmin.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/panel.css')); ?>" rel="stylesheet">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <script src="https://kit.fontawesome.com/642ec4bc32.js" crossorigin="anonymous"></script>
    <title>panel</title>
    <link rel="icon" type="image/png" href="/storage/icon.png">
</head>

<body class="bg-light">

<nav class="navbar navbar-expand navbar-dark bg-primary">
    <a class="navbar-brand" href="../home">Beheerders Paneel</a>
</nav>

<div class="d-flex">
    <div class="sidebar sidebar-dark bg-dark">
        <ul class="list-unstyled">
            <li><a href="../home" class="margin">Home</a></li>
            <li><a href="<?php echo e(url('/admin/users')); ?>" class="margin">Gebruikers</a></li>
            <li><a href="<?php echo e(url('/admin/posts')); ?>" class="margin">Posts</a></li>
            <li><a href="<?php echo e(url('/admin/FAQ')); ?>" class="margin">FAQ</a></li>
        <li><a href="<?php echo e(url('/admin/aanvragen')); ?>" class="margin">Aanvragen</a></li>
        </ul>
    </div>
        <main class="main">
            <?php echo $__env->yieldContent('content'); ?>
        </main>
</div>
</body>
</html><?php /**PATH C:\Deltionn\sprint7\keukrenrepo\resources\views/layouts/dashboard.blade.php ENDPATH**/ ?>