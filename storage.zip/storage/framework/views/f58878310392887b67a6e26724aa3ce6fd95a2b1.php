
<?php $__env->startSection('content'); ?>
<div class="container">
    <style>
        html { scroll-behavior: smooth; }
    </style>
    <link rel="stylesheet" href="<?php echo e(asset('css/bootstrap.min.css')); ?>">
    <h2>Create Post</h2>
    <?php echo Form::open(['action' => 'PostsAdminController@store', 'method' => 'POST', 'enctype' => 'multipart/form-data']); ?>

    <div class="form-group">
        <?php echo e(Form::file('cover_image')); ?>

    </div>
        <div class="form-group">
            <?php echo e(Form::label('title', 'Title')); ?>

            <?php echo e(Form::text('title', '', ['placeholder' => 'Title', 'class' =>'form-control'])); ?>

        </div>
        <div class="form-group">
            <?php echo e(Form::label('body', 'Body')); ?>

            <?php echo e(Form::textarea('body', '', ['id' => 'article-ckeditor', 'placeholder' => 'Body', 'class' =>'form-control'])); ?>

        </div>
        <div class="form-group">
            <?php echo e(Form::label('type', 'Type')); ?>

            <?php echo e(Form::select('type', array('' => 'Selecteer een type post', 
                                         'news' => 'News', 
                                         'keuken' => 'Keukens'))); ?>

        </div>
        <?php echo e(Form::submit('Submit', ['class' =>'btn btn-success'])); ?>

    <?php echo Form::close(); ?>

    <hr>
    <br>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Deltionn\sprint7\keukrenrepo\resources\views/panel/makePost.blade.php ENDPATH**/ ?>