
<?php $__env->startSection('content'); ?>
    <style>
        html { scroll-behavior: smooth; }
    </style>
    <link rel="stylesheet" href="<?php echo e(asset('css/bootstrap.min.css')); ?>">
    <h2>Create Post</h2>
    <?php echo Form::open(['action' => 'PostsController@store', 'method' => 'POST', 'enctype' => 'multipart/form-data']); ?>

    <div class="form-group">
        <div class="custom-file">
        <?php echo e(Form::file('cover_image', ['class' => 'custom-file-input'])); ?>

            <label class="custom-file-label" for="customFileLangHTML" data-browse="Bestand kiezen">Voeg je document toe</label>
        </div>
    </div>
        <div class="form-group">
            <?php echo e(Form::label('title', 'Title')); ?>

            <?php echo e(Form::text('title', '', ['placeholder' => 'Title', 'class' =>'form-control'])); ?>

        </div>
        <div class="form-group">
            <?php echo e(Form::label('body', 'Body')); ?>

            <?php echo e(Form::textarea('body', '', ['id' => 'article-ckeditor', 'placeholder' => 'Body', 'class' =>'form-control'])); ?>

        </div>
        <div class="form-group">
            <?php echo e(Form::label('type', 'Type')); ?><br>
            <?php echo e(Form::select('type', array('' => 'Selecteer een type post', 
                                         'news' => 'Nieuws', 
                                         'keuken' => 'Keukens'), null, ['class' => 'box'])); ?>

        </div>
        <?php echo e(Form::submit('Submit', ['class' =>'btn btn-success'])); ?>

    <?php echo Form::close(); ?>

    <hr>
    <br>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Deltionn\sprint7\keukrenrepo\resources\views/posts/create.blade.php ENDPATH**/ ?>