<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta charset="utf-8">
    <meta name="author" content="keukenfabrikant">
    <meta name="keywords" content="Keukenfabrikant, keukens, Keukens, Keukenfabrikant, keuken, Keuken">
    <meta name="description" content="Keukenfabrikant">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title><?php echo e(config('app.name', 'error')); ?></title>
    <script src="<?php echo e(asset('js/app.js')); ?>" defer></script>
    <link rel="dns-prefetch" href="//fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css?family=Nunito" rel="stylesheet">
    <link href="<?php echo e(asset('css/main.css')); ?>" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo e(asset('css/bootstrap.min.css')); ?>">
    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo e(asset('css/bootstrap.min.css')); ?>">
    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/home.css')); ?>" rel="stylesheet">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <script src="https://kit.fontawesome.com/5a37eae510.js" crossorigin="anonymous"></script>
    <link rel="dns-prefetch" href="//fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css?family=Nunito" rel="stylesheet">
    <script src="https://cdn.ckeditor.com/ckeditor5/16.0.0/classic/ckeditor.js"></script>
    <script src="https://kit.fontawesome.com/5a37eae510.js" crossorigin="anonymous"></script>
    <script src="https://code.jquery.com/jquery-3.4.1.min.js" integrity="sha256-CSXorXvZcTkaix6Yvo6HppcZGetbYMGWSFlBw8HfCJo=" crossorigin="anonymous"></script>
    <link rel="icon" type="image/png" href="/storage/icon.png">
    <title><?php echo e(config('app.name')); ?></title>
    </head>
    <body>
    <!-- Authentication Links -->
    <?php if(auth()->guard()->guest()): ?>
    <div id="app">
            <?php echo $__env->make('partials.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
        <br>
            <?php echo $__env->make('inc.messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <div class="row">
                <div class="col-md-12">
                    <div class="topbanner">
                        <img src="/storage/app/public/topbanner.jpg"></img>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-sm-2">
                    <div class="sidebar-left">
                            <img src="/storage/keukenbanner.jpg"></img>
                    </div>
                </div>

                <div class="col-sm-8">
                    <?php echo $__env->yieldContent('content'); ?>
                </div>

                <div class="col-sm-2">
                    <div class="sidebar-right">
                        <img src="/storage/keukenbanner.jpg"></img>
                    </div>
                </div>
    <?php endif; ?>
    <?php if(auth()->guard()->check()): ?>
    <?php if(Auth::user()->blocked == '1'): ?>
         <div id="app">
            <?php echo $__env->make('partials.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
        <div class="container">
            <br>
            <h3 class="pb-3 mb-4 border-bottom">
                Dit account is geblokkeerd
             </h3>
             <p>Uw account is helaas tijdelijk/permanent geblokkeerd vanwege 1 van de volgende redenen:</p>
             <p>- Er zijn verdachte activiteiten op uw account.</p>
             <p>- Uw account is mogelijk als bot geindentificeerd als bot.</p>
             <p>- U heeft onze regels verbroken.</p><br>
             <p>Om meer te weten te komen achter de reden van uw blokkade stuur een mail via ons contact formulier met de volgende gegevens</p>
             <p>- Uw Gebruikersnaam</p>
             <p>- Uw E-mail</p><br>
             <p>- Waarom u mogelijk denkt geblokkeerd te zijn</p><br>
             <p>na het verzenden van deze mail zult u te horen krijgen wat de reden is en of deze blokkade te verheffen is.</p>
             <br>
             <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST">
                <button class="btn btn-success"><a style="text-decoration: none; color: black;" href="<?php echo e(route('logout')); ?>">log uit</a></button>
                <?php echo csrf_field(); ?>
            </form>
        </div>
    <?php else: ?> 
        <div id="app">
            <?php echo $__env->make('partials.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
        <br>
            <?php echo $__env->make('inc.messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <div class="row">
                <div class="col-md-8">
                SIDEBAR
                </div>
            </div>
            <div class="row">
                <div class="col-sm-2">
                    <div class="sidebar-left">
                            <img src="/storage/keukenbanner.jpg"></img>
                    </div>
                </div>

                <div class="col-sm-8">
                    <?php echo $__env->yieldContent('content'); ?>
                </div>

                <div class="col-sm-2">
                    <div class="sidebar-right">
                        <img src="/storage/app/public/keukenbanner.jpg"></img>
                    </div>
                </div>
    <?php endif; ?>
    <?php endif; ?>
</body>
</html><?php /**PATH C:\Deltionn\sprint7\keukrenrepo\resources\views/layouts/master.blade.php ENDPATH**/ ?>