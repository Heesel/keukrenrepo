
<?php $__env->startSection('content'); ?>
    <div class="container">
    <button class="btn btn-success btn-lg"><a href="/Aposts/create"> Nieuwe post aanmaken</a></button>
        <div class="d-flex justify-content-center">
        <table class="table table-bordered">
            <thead class="thead-dark">
            <tr>
                <th scope="col">id</th>
                <th scope="col">titel</th>
                <th scope="col">gebruiker</th>
                <th scope="col">bewerken</th>
                <th scope="col">verwijder</th>
                <th scope="col">status</th>
            </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <th scope="row"><?php echo e($post->id); ?></th>
                <td><?php echo e($post->title); ?></td>
                <td><?php echo e($post->user_id); ?></td>
                <td><button class="btn btn-success"><a href="/posts/<?php echo e($post->id); ?>/edit">bewerken</a></button></td>
                <td>
                    <?php echo Form::open(['action' => ['PostsController@destroy', $post->id], 'method' => 'POST', 'class' => 'pull-right']); ?>

                        <?php echo e(Form::hidden('_method', 'DELETE')); ?>

                        <?php echo e(Form::submit('Delete', ['class' => 'btn btn-danger'])); ?>

                    <?php echo Form::close(); ?>

                </td>
                <?php if($post->approved == 0): ?>
                <td>niet betaald</td>
                <?php elseif($post->approved == 1): ?>
                <td>betaald</td>
                <?php endif; ?>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
    </div>
</div>
<script type="text/javascript">
    $('.confirmation').click(function(e){
        let result = confirm("Weet je zeker dat je de foto wilt verwijderen?");
        if(!result) {
            e.preventDefault();
        }
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Deltionn\sprint7\keukrenrepo\resources\views/panel/posts.blade.php ENDPATH**/ ?>