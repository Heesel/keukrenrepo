
<?php $__env->startSection('content'); ?>


      <h3 class="pb-3 mb-4 border-bottom">
         Keukens
      </h3>
      <div class="row">
         <?php if(count($posts2) > 0): ?>
         <?php $__currentLoopData = $posts2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
         <div class="col-md-6">
            <div class="card flex-md-row mb-4 shadow-sm h-md-250">
               <div class="card-body d-flex flex-column align-items-start">
                  <strong class="d-inline-block mb-2">Keuken te koop</strong>
                  <h6 class="mb-0">
                     <a class="text-dark" href="/posts/<?php echo e($post->id); ?>"><?php echo e($post->title); ?></a>
                  </h6>
                  <a href="/profile/<?php echo e($post->user_id); ?>" style="text-decoration: none; color: black;"><div class="mb-1 text-muted small">geschreven door <?php echo e($post->user->name); ?></a>
               </div>
               <p class="card-text mb-auto"> <?php echo \Illuminate\Support\Str::limit($post->body ?? '',50,'...'); ?></p>
               <a class="btn btn-success btn-sm" href="/posts/<?php echo e($post->id); ?>">Lees meer</a>
               <?php if(auth()->guard()->check()): ?>
                  <a href="javascript:void(0);" onclick="document.getElementById('favorite-form-<?php echo e($post->id); ?>').submit();">
                     <i class="fas fa-heart"></i>
                  </a>
                  <form id="favorite-form-<?php echo e($post->id); ?>" method="POST" action="<?php echo e(route('post.favorite', $post->id)); ?>" style="display: none;">
                     <?php echo csrf_field(); ?>
                  </form>
               <?php endif; ?>
            </div>
            <img class="card-img-right flex-auto d-none d-lg-block" alt="" src="/storage/cover_images/<?php echo e($post->cover_image); ?>" style="width: 275px; height: 225px;">
         </div>
      </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      <?php else: ?>
         <p>no posts found</p>
      <?php endif; ?>
      <a class="btn btn-success btn-sm all" href="/keukens">Bekijk alle keukens</a>
      </div>
         
      <h3 class="mt-3 pb-3 mb-4 border-bottom">
        Keuken Nieuws
     </h3>
     <div class="row">
      <?php if(count($posts1) > 0): ?>
      <?php $__currentLoopData = $posts1; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <div class="col-md-6">
         <div class="card flex-md-row mb-4 h-md-250">
            <div class="card-body d-flex flex-column align-items-start">
               <strong class="d-inline-block mb-2">Keuken nieuwtjes</strong>
               <h6 class="mb-0">
                  <a class="text-dark" href="/posts/<?php echo e($post->id); ?>"><?php echo e($post->title); ?></a>
               </h6>
               <a href="/profile/<?php echo e($post->user_id); ?>" style="text-decoration: none; color: black;"><div class="mb-1 text-muted small">geschreven door <?php echo e($post->user->name); ?></a>
            </div>
            <p class="card-text mb-auto"> <?php echo \Illuminate\Support\Str::limit($post->body ?? '',50,'...'); ?></p>
            <a class="btn btn-success btn-sm" href="/posts/<?php echo e($post->id); ?>">Lees meer</a>
         </div>
         <img class="card-img-right" alt="" src="/storage/cover_images/<?php echo e($post->cover_image); ?>">
      </div>
   </div>
   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
   <?php else: ?>
      <p>no posts found</p>
   <?php endif; ?>
   <a class="btn btn-success btn-sm all" href="/keukens">Bekijk al het niews</a>
     </div>
     
     <!-- </div> -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Deltionn\sprint7\keukrenrepo\resources\views/posts/index.blade.php ENDPATH**/ ?>