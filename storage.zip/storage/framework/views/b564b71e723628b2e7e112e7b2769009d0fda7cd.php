<?php echo e($slot); ?>: <?php echo e($url); ?>

<?php /**PATH C:\Deltionn\sprint7\keukrenrepo\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/button.blade.php ENDPATH**/ ?>