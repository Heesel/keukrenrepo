
<?php $__env->startSection('content'); ?>
    <div class="container">

        <form action="/search" method="GET">
        <div class="search">
            <input type="text" class="searchTerm" name="pUser" placeholder="Gebruikersnaam...">
            <button type="submit" class="searchButton">
              <i class="fa fa-search"></i>
           </button>
         </div>
        </form>
        <?php if(empty($search)): ?>
        <div class="d-flex justify-content-center">
            <table class="table table-bordered">
                <thead class="thead-dark">
                <tr>
                    <th scope="col">id</th>
                    <th scope="col">naam</th>
                    <th scope="col">e-mail</th>
                    <th scope="col">functie</th>
                    <th scope="col">bewerken</th>
                    <th scope="col">verwijder</th>
                    <th scope="col">status</th>
                </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <th scope="row"><?php echo e($user->id); ?></th>
                    <td><?php echo e($user->name); ?></td>
                    <td><?php echo e($user->email); ?></td>
                    <td><?php echo e($user->role); ?></td>
                    <td><button class="btn btn-success"><a href='/admin/users/<?php echo e($user->id); ?>/edit'>bewerken</a></button></td>
                    <td>
                        <?php echo Form::open(['action' => ['userController@destroy', $user->id], 'method' => 'POST']); ?>

                            <?php echo e(Form::hidden('_method', 'DELETE')); ?>

                            <?php echo e(Form::submit('verwijderen', ['class' => 'btn btn-danger'])); ?>

                        <?php echo Form::close(); ?>

                    </td>
                    <td><?php 
                        if($user->blocked == 1) {?> geblokkeerd <?php } else { ?> geen <?php } ?></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </table>
        </div>
        <?php elseif(count($search) >= 1): ?>
        <div class="d-flex justify-content-center">
            <table class="table table-bordered">
                <thead class="thead-dark">
                <tr>
                    <th scope="col">id</th>
                    <th scope="col">naam</th>
                    <th scope="col">e-mail</th>
                    <th scope="col">functie</th>
                    <th scope="col">bewerken</th>
                    <th scope="col">verwijder</th>
                    <th scope="col">status</th>
                </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $search; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <th scope="row"><?php echo e($user->id); ?></th>
                        <td><?php echo e($user->name); ?></td>
                        <td><?php echo e($user->email); ?></td>
                        <td><?php echo e($user->role); ?></td>
                        <td><button class="btn btn-success"><a href='/admin/users/<?php echo e($user->id); ?>/edit'>bewerken</a></button></td>
                        <td>
                            <?php echo Form::open(['action' => ['userController@destroy', $user->id], 'method' => 'POST']); ?>

                                <?php echo e(Form::hidden('_method', 'DELETE')); ?>

                                <?php echo e(Form::submit('verwijderen', ['class' => 'btn btn-danger'])); ?>

                            <?php echo Form::close(); ?>

                        </td>
                        <td><?php 
                            if($user->blocked == 1) {?> geblokkeerd <?php } else { ?> geen <?php } ?></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </table>
            </div>
            <?php else: ?>
                Geen gebruikers gevonden
        <?php endif; ?>
        
</div>
<script type="text/javascript">
    $('.confirmation').click(function(e){
        let result = confirm("Weet je zeker dat je de gebruiker wilt verwijderen?");
        if(!result) {
            e.preventDefault();
        }
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Deltionn\sprint7\keukrenrepo\resources\views/panel/users.blade.php ENDPATH**/ ?>